from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'your-team-name',
    'start_date': datetime(2025, 6, 16),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'dbt_prophecy_pipeline',
    default_args=default_args,
    description='Orchestrate dbt models with Airflow',
    schedule_interval='0 0 * * *',
    catchup=False,
) as dag:

    dbt_compile = BashOperator(
        task_id='dbt_compile',
        bash_command='cd $AIRFLOW_HOME/your-prophecy-dbt-repo && dbt compile'
    )

    dbt_test = BashOperator(
        task_id='dbt_test',
        bash_command='cd $AIRFLOW_HOME/your-prophecy-dbt-repo && dbt test'
    )

    dbt_run_model1 = BashOperator(
        task_id='dbt_run_model1',
        bash_command='cd $AIRFLOW_HOME/your-prophecy-dbt-repo && dbt run --select your_model1'
    )

    dbt_run_model2 = BashOperator(
        task_id='dbt_run_model2',
        bash_command='cd $AIRFLOW_HOME/your-prophecy-dbt-repo && dbt run --select your_model2'
    )

    dbt_compile >> dbt_test >> [dbt_run_model1, dbt_run_model2]
